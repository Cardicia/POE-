﻿using System;
using System.Collections.Generic;

namespace Part2C
{
    public class MainProgram
    {
        private static List<Recipe> recipes = new List<Recipe>();

        // Event to handle recipe exceeding calories
        public static event RecipeExceedsCaloriesHandler RecipeExceedsCaloriesEvent;

        private static void HandleRecipeExceedsCalories(string recipeName)
        {
            Console.WriteLine($"Warning: {recipeName} exceeds the recommended calorie limit of 300!");
        }

        public static void Main(string[] args)
        {
            bool running = true;

            // Subscribe to the RecipeExceedsCaloriesEvent event
            RecipeExceedsCaloriesEvent += HandleRecipeExceedsCalories;

            while (running)
            {
                Console.WriteLine("*************************************");
                Console.WriteLine("1. New Recipe");
                Console.WriteLine("*************************************");
                Console.WriteLine("2. Show all stored recipes");
                Console.WriteLine("*************************************");
                Console.WriteLine("3. Select a particular stored recipe");
                Console.WriteLine("*************************************");
                Console.WriteLine("4. Delete a recipe");
                Console.WriteLine("*************************************");
                Console.WriteLine("5. Shutdown application");
                Console.WriteLine("*************************************");
                Console.WriteLine();
                Console.Write("SELECT OPTION:");
                string userOption = Console.ReadLine();

                if (userOption == "1")
                {
                    NewRecipe();
                }
                else if (userOption == "2")
                {
                    DisplayRecipes();
                }
                else if (userOption == "3")
                {
                    SelectRecipeFromList();
                }
                else if (userOption == "4")
                {
                    DeleteRecipe();
                }
                else if (userOption == "5")
                {
                    Console.WriteLine("Goodbye!");
                    running = false;
                }
                else
                {
                    Console.WriteLine("Choice was invalid. Please choose a valid option from the menu.");
                }

                Console.WriteLine();
            }
        }

        private static void NewRecipe()
        {
            Recipe recipe = new Recipe();

            Console.Write("Enter the name of the recipe: ");
            string recipeName = Console.ReadLine();

            while (string.IsNullOrWhiteSpace(recipeName))
            {
                Console.WriteLine("Recipe name cannot be empty or whitespace. Please enter a valid name.");
                Console.Write("Enter the name of the recipe: ");
                recipeName = Console.ReadLine();
            }

            recipe.Name = recipeName;

            // Enter ingredients
            recipe.Ingredients = new List<RecipeIngredients>();

            Console.Write("Enter the number of ingredients: ");
            int ingredientCount = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < ingredientCount; i++)
            {
                Console.WriteLine($"Enter details for ingredient #{i + 1}:");

                RecipeIngredients ingredient = new RecipeIngredients();

                Console.Write("Name: ");
                ingredient.Name = Console.ReadLine();

                Console.Write("Quantity: ");
                double quantity = Convert.ToDouble(Console.ReadLine());

                while (quantity < 0)
                {
                    Console.WriteLine("Quantity cannot be negative. Please enter a valid quantity.");
                    Console.Write("Quantity: ");
                    quantity = Convert.ToDouble(Console.ReadLine());
                }

                ingredient.Quantity = quantity;

                Console.Write("Unit: ");
                ingredient.Unit = Console.ReadLine();

                Console.Write("Calories: ");
                ingredient.Calories = Convert.ToDouble(Console.ReadLine());

                Console.Write("Food Group: ");
                ingredient.FoodGroup = Console.ReadLine();

                recipe.Ingredients.Add(ingredient);
            }

            // Raise event if recipe exceeds calorie limit
            recipe.CheckCalories();

            recipes.Add(recipe);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Your recipe has been added to the list!");
            Console.ResetColor();

            // Display the added recipe for confirmation
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Recipe Details:");
            Console.ResetColor();
            recipe.DisplayRecipe();
        }

        private static void DisplayRecipes()
        {
            Recipe.DisplayRecipeList(recipes);
        }

        private static void SelectRecipeFromList()
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes have been found.");
                return;
            }

            Console.WriteLine("Select a recipe from the list:");

            for (int i = 0; i < recipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipes[i].Name}");
            }

            Console.Write("Enter the recipe number: ");
            try
            {
                int recipeNumber = Convert.ToInt32(Console.ReadLine());

                if (recipeNumber >= 1 && recipeNumber <= recipes.Count)
                {
                    Recipe selectedRecipe = recipes[recipeNumber - 1];
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine($"Details of Recipe: {selectedRecipe.Name}");
                    Console.ResetColor();
                    selectedRecipe.DisplayRecipe();
                }
                else
                {
                    Console.WriteLine("Invalid recipe number. Please enter a valid recipe number.");
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid input. Please enter a valid recipe number.");
            }
        }

        private static void DeleteRecipe()
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes have been found.");
                return;
            }

            Console.WriteLine("Select a recipe to delete:");

            for (int i = 0; i < recipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipes[i].Name}");
            }

            Console.Write("Enter the recipe number: ");
            try
            {
                int recipeNumber = Convert.ToInt32(Console.ReadLine());

                if (recipeNumber >= 1 && recipeNumber <= recipes.Count)
                {
                    Recipe selectedRecipe = recipes[recipeNumber - 1];
                    recipes.Remove(selectedRecipe);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Recipe \"{selectedRecipe.Name}\" has been deleted.");
                    Console.ResetColor();
                }
                else
                {
                    Console.WriteLine("Invalid recipe number. Please enter a valid recipe number.");
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid input. Please enter a valid recipe number.");
            }
        }
    }
}
