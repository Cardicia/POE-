﻿namespace Part2C
{
    // Represents an ingredient in a recipe
    public class RecipeIngredients
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }
    }
}
