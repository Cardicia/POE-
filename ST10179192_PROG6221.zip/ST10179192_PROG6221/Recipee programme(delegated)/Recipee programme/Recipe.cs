﻿using System;
using System.Collections.Generic;

namespace Part2C
{
    // Delegate for recipe exceeding calories event
    public delegate void RecipeExceedsCaloriesHandler(string recipeName);

    public class Recipe
    {
        public string Name { get; set; }
        public List<RecipeIngredients> Ingredients { get; set; }
        public event RecipeExceedsCaloriesHandler RecipeExceedsCaloriesEvent;

        public Recipe()
        {
            Ingredients = new List<RecipeIngredients>();
        }

        public void CheckCalories()
        {
            double totalCalories = CalculateTotalCalories();
            if (totalCalories > 300)
            {
                RecipeExceedsCaloriesEvent?.Invoke(Name);
            }
        }

        public double CalculateTotalCalories()
        {
            double totalCalories = 0;
            foreach (RecipeIngredients ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories;
            }
            return totalCalories;
        }

        public void DisplayRecipe()
        {
            Console.WriteLine($"Recipe: {Name}");
            Console.WriteLine("Ingredients:");
            Console.WriteLine("*********************************************");
            Console.WriteLine("| No. | Name             | Calories |");
            Console.WriteLine("*********************************************");

            for (int i = 0; i < Ingredients.Count; i++)
            {
                RecipeIngredients ingredient = Ingredients[i];
                Console.WriteLine($"| {i + 1,-3} | {ingredient.Name,-16} | {ingredient.Calories,-8} |");
            }

            Console.WriteLine("*********************************************");

            double totalCalories = CalculateTotalCalories();
            Console.WriteLine($"Total calories: {totalCalories}");
        }

        public static void DisplayRecipeList(List<Recipe> recipes)
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes found.");
                return;
            }

            Console.WriteLine("Stored Recipes:");
            Console.WriteLine("*********************************************");

            for (int i = 0; i < recipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipes[i].Name}");
            }

            Console.WriteLine("*********************************************");
        }
    }
}
