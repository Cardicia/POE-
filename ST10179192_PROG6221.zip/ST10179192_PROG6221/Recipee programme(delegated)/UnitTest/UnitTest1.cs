using Recipeeprogramme;
namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
        public delegate void RecipeExceedsCaloriesHandler(string recipeName);
    }
}